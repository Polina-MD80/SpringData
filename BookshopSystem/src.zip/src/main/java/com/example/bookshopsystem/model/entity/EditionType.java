package com.example.bookshopsystem.model.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD;
}
