package com.example.bookshopsystem.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
