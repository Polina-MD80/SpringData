package entity;

public enum CardType {
    VISA,
    MASTERCARD,
    MAESTRO;
}
