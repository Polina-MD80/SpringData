package com.example.springintro.model.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
